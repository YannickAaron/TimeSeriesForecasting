__version__ = '0.15.0.dev20221020'
git_version = '39a400e96fe094cda1c27989742e80cd089742d6'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
